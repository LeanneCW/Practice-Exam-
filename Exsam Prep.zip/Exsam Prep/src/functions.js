function hello(name){
   return(`hello ${name}`);
}


function celsius2fahrenheit(celsius){
   const fahrenheit = celsius *9 /5 + 32;
   return(fahrenheit);
}
function sf2acres(sf){
   const acres = sf/43560;
   return(acres);
}

function lawnMowingAdventures(width,length,timeperarea) 
 {
    let time = (width) * (length) * (timeperarea);
    return Math.round (time);
}
function stayingalive(AQI) {
    let index;
    if (AQI < 50) {
        index = 'Good';
    } else if (AQI < 100) {
        index = 'Moderate';
    } else if (AQI < 150) {
        index = 'Unhealthy for Sensitive Groups';
    } else if (AQI < 200) {
        index = 'Unhealthy';
    } else if (AQI < 300) {
        index = 'Very Unhealthy';
    } else if (AQI > 300) {
        index = 'Hazardous!';
    }
    return index;
}

function shouting(number) {
    let shout;
if (number %3 === 0) {
  shout = 'Yee';
} else if (number %7 === 0) {
  shout = `Ha`;
} else if ( number %7 === 0 && number %3 === 0 ) {
  shout = `YeeHa`;
} else {
  shout = `Nada`;
}
return shout;
}

function slope(x1,x2,y1,y2) 
 {
    let slope = (y2-y1)/(x2-x1);
    return Math.round (slope);
}






export {hello, celsius2fahrenheit, sf2acres, stayingalive, lawnMowingAdventures, shouting, slope}