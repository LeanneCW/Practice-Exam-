import {hello, celsius2fahrenheit, sf2acres, lawnMowingAdventures, stayingalive, shouting, slope} from './functions.js';


function Question1(){
   return <section>
   <h2>Question One</h2>
1. Write a function that takes a _name_ as an argument and _returns a string_ that _contains "hello"_ and the name paramerer. Test at least 3 names. <br />*Note ... I solved this one already
     <h3>Results</h3>
     <p>hello("Rich") == "{hello('Rich')}"</p>
     <p>hello("Bill") == "{hello('Bill')}"</p>
     <p>hello("Chris") == "{hello('Chris')}"</p>
   </section>;
}


function Question2(){
   return <section>
    <h2>Question Two</h2>
2. Write a function that converts celsius to fahrenheit
<h3>Results</h3>
<p>celsius2fahrenheit(37.7777) == "{celsius2fahrenheit(37.7777)}"</p>
   </section>;
}


function Question3(){
   return <section>
<h2>Question Three</h2>
3. There are 43,560 square feet per acre. Write a program that converts square feet to acres. Test at least 3 conversions.
<h3>Results</h3>
<p>sf2acres(100000) == {sf2acres(100000)}</p>
   </section>;
}
function Question4(){
   return <section>
<h2>Question Four</h2>
4. Given the&nbsp; width of a lawn in metres, length of a lawn in metres and the square metres cut per minute calculate the minutes it would take to mow that lawn. 
<h3>Results</h3>
<p>lawnMowingAdventures(15) == {lawnMowingAdventures(15)} </p>
   </section>;
}

function Question5(){
   return <section>
<h2>Question Four</h2>
5. Compute the air quality given an air quality index:
<h3>Results</h3>
<p>stayingalive(150) == {stayingalive(150)} </p>
   </section>;
}

function Question6(){
   return <section>
<h2>Question Four</h2>
6. yee_ha takes an integer parameter and returns one of the following strings:
<h3>Results</h3>
<p>shouting(21) == {shouting(21)} </p>
   </section>;
}

function Question7(){
   return <section>
<h2>Question Four</h2>
7. Calculate the slope of a line.
<h3>Results</h3>
<p>slope(1,3,3,1) == {slope(1,3,3,1)} </p>
   </section>;
}





export {Question1, Question2, Question3, Question4, Question5, Question6, Question7}