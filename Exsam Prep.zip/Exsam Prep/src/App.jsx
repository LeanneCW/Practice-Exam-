import {Question1, Question2, Question3, Question4, Question5, Question6, Question7} from './components.jsx';


function App() {
 return (
   <>
       <Question1 />   
       <Question2 />
       <Question3 />
       <Question4 />
       <Question5 />
       <Question6 />
       <Question7 />
   </>
 )
}


export default App


